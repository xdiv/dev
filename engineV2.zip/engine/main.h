#pragma once
class main
{
public:
	main(void);
	~main(void);
};

